# sntc
Website for SNTC, IIT Mandi
